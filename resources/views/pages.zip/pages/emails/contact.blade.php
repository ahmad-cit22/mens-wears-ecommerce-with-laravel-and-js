<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <p>Name: {{ $data->name }}</p>
 <p>Email: {{ $data->email }}</p>
 <p>Phone: {{ $data->phone }}</p>
 <p>Subject: {{ $data->subject }}</p>
 <p>Message: {{ $data->message }}</p>
</body>
</html>