<!-- /.content-wrapper -->
<footer class="main-footer hidden-print">
  <strong>&copy; {{ date('Y') }} <a href="{{ env('APP_URL') }}">{{ env('APP_NAME') }}</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">

  </div>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

@include('admin.partials.scripts')


</body>
</html>
