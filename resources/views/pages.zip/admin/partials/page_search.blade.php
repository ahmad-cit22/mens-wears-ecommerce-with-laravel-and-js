<div class="row mt-3 mb-2">
    <div class="col-10"></div>
    <div class="col-2">
        <div class="d-flex" style="gap: 10px;">
            <input id="page-search-field" class="form-control" type="number" name="pageNo" placeholder="Go to Page" style="width: 66%">
            <button id="page-search-btn" class="btn btn-sm btn-primary" type="button"><i class="fas fa-location-arrow mr-1" style="font-size: 10px !important"></i>Go</button>
        </div>
    </div>
</div>
